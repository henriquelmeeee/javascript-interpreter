g++ main.cpp -o main
./main
