#include "Forward.h"
#include "Scope.h"
#include "Variable.h"

Value Scope::execute(Scope* context) {
  return Value(BOOLEAN);
};

