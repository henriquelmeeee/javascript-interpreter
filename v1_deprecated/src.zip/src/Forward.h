#pragma once

#ifndef FORWARD
#define FORWARD

#include <stdio.h>
#include <stdlib.h>
#include <cstring>
#include <string>
#include <iostream>

#include <vector>
#include <map>
#include <variant>

#define cout std::cout
#define cin std::cin
#define endl std::endl

#endif
