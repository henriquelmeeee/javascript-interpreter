#pragma once

#ifndef BREAKPOINT
#define BREAKPOINT

#include "AST.h"

//void Breakpoint(ASTNode* who, ForwardScope* context);


#endif
